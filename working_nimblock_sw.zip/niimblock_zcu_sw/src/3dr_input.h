#ifndef THREEDR_INPUT_H
#define THREEDR_INPUT_H
#include "nimblock_types.h"

void read_triangles(u32* buf_3dr);


#endif