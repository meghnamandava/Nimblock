

/***************************** Include Files *******************************/
#include "reconfig_block_blank_mang.h"

/************************** Function Definitions ***************************/
