/*
 * Empty C++ Application
 */

/*int main()
{
	return 0;
}*/

/*
 * Sample demo application that showcases inter processor
 * communication from linux userspace to a remote software
 * context. The application generates random matrices and
 * transmits them to the remote context over rpmsg. The
 * remote application performs multiplication of matrices
 * and transmits the results back to this application.
 */

#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <time.h>
#include <fcntl.h>
#include <pthread.h>
#include <string.h>
#include <linux/rpmsg.h>
#include <chrono>
#include "nimblock_types_host.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <cstring>
#include "picojson.h"
#include <arpa/inet.h>
#include <netinet/in.h>
#include <random>

#define RPMSG_BUS_SYS "/sys/bus/rpmsg"

#define PORT 8000
#define BACKLOG 2
#define BUFFER_SIZE 1024

static pthread_t ui_thread, compute_thread;
static pthread_mutex_t sync_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t read_cond = PTHREAD_COND_INITIALIZER;
static int done_writing = 0;
static int done_reading = 1;

static pthread_t schedule_thread, app_thread, stop_thread;
static pthread_mutex_t msg_lock = PTHREAD_MUTEX_INITIALIZER;;

static int charfd = -1, fd, compute_flag;
static int ntimes = 1;

#define RPMSG_GET_KFIFO_SIZE 1
#define RPMSG_GET_FREE_SPACE 3

static int curr_req_id;
std::map<int,int> requests;
std::chrono::microseconds SCHED_INTERVAL = std::chrono::microseconds(50000);

void *schedule_trigger_thread(void *ptr) {
	Nimblock_msg * my_app;
	auto initial = std::chrono::high_resolution_clock::now();

	while(compute_flag!=0) {

		auto cur = std::chrono::high_resolution_clock::now();
		auto time_diff = std::chrono::duration_cast<std::chrono::microseconds>(cur-initial);

		if (time_diff >= SCHED_INTERVAL) {
			my_app = new Nimblock_msg();
			//printf("\r\nTriggering scheduling\r\n");
			//pthread_mutex_lock(&sync_lock);
			//printf("\r\nTriggering scheduling\r\n");
			pthread_mutex_lock(&msg_lock);
			while (done_reading != 1) {
				pthread_cond_wait(&read_cond, &msg_lock);
			}
			done_reading = 0;
			write(fd, my_app, sizeof(*my_app));
			pthread_mutex_unlock(&msg_lock);
			done_writing = 1;
			pthread_cond_signal(&read_cond);
			initial = std::chrono::high_resolution_clock::now();
		}


	}
	return 0;
}

void *send_app_sock_thread(void *ptr) {

	int server_fd, new_socket;
	struct sockaddr_in address;
	int opt = 1;
	int addrlen = sizeof(address);
	char buffer[BUFFER_SIZE] = {};
	std::string data_string;
	//std::string filename;

	std::ofstream outfile;


	server_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (server_fd == -1) {
		perror("socket failed");
		exit(EXIT_FAILURE);
	}

	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) {
		perror("setsockopt failed");
		exit(EXIT_FAILURE);
	}

	address.sin_family = AF_INET;
	address.sin_addr.s_addr = htonl(INADDR_ANY);
	address.sin_port = htons(PORT);

	if (bind(server_fd, (struct sockaddr*) &address, sizeof(address))<0) {
		perror("bind failed");
		exit(EXIT_FAILURE);
	}

	if (listen(server_fd, BACKLOG) < 0) {
		perror("listen failed");
		exit(EXIT_FAILURE);
	}


	printf("Nimblock server listening.\n");
	while (compute_flag == 1) {
		new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
		if (new_socket < 0) {
			perror("accept failed");
			exit(EXIT_FAILURE);
		}

		printf("Accepted connection, socketfd %d\n", new_socket);
		Nimblock_msg * my_app;

		int valread = read(new_socket, buffer, BUFFER_SIZE);
		if (valread < 0) {
			perror("read failed");
			exit(EXIT_FAILURE);
		}

		//close(new_socket);

		data_string = buffer;

		picojson::value v;
		std::string error = picojson::parse(v, data_string);
		if (!error.empty()) {
			std::cerr << error << std::endl;
			exit(EXIT_FAILURE);
		}

		int app, batch, priority;

		std::string filedata = v.get("data").to_str();
		app = stoi(v.get("app").to_str());
		batch = stoi(v.get("batch").to_str());
		priority = stoi(v.get("priority").to_str());

		std::string filename = "new_file.txt";
		outfile.open(filename, std::ios::binary);
		outfile.write(filedata.c_str(), 1024);
		outfile.close();

		//int app, batch, priority;
		my_app = new Nimblock_msg(ADD_APP, priority, batch, app, ++curr_req_id);
		requests[curr_req_id] = new_socket;

		//pthread_mutex_lock(&sync_lock);
		printf("\nGot app %d with batch %d and priority %d, assigned req id %d.\n", app, batch, priority, my_app->req_id);
		pthread_mutex_lock(&msg_lock);
		while (done_reading != 1) {
			pthread_cond_wait(&read_cond, &msg_lock);
		}
		done_reading = 0;
		write(fd, my_app, sizeof(*my_app));
		pthread_mutex_unlock(&msg_lock);
		done_writing = 1;
		pthread_cond_signal(&read_cond);
	}

	close(server_fd);

	return 0;
}

void *stop_nimblock_thread(void *ptr) {

	int exit = 0;
	Nimblock_msg * my_app;
	while(1) {
		printf("\r\nEnter 1 to exit\r\n");
		scanf("%d", &exit);
		if (exit == 1) {
			my_app = new Nimblock_msg(SHUTDOWN, 0, 0, 0, 0);
		}
		//pthread_mutex_unlock(&sync_lock);
		//pthread_mutex_lock(&sync_lock);
		printf("\r\nExiting\r\n");
		pthread_mutex_lock(&msg_lock);
		while (done_reading != 1) {
			pthread_cond_wait(&read_cond, &msg_lock);
		}
		done_reading = 0;
		write(fd, my_app, sizeof(*my_app));
		pthread_mutex_unlock(&msg_lock);
		done_writing = 1;
		pthread_cond_signal(&read_cond);
		compute_flag = 0;
		break;

	}
	printf("\nExiting");
	return 0;
}

void *ui_thread_entry_app(void *ptr)
{
	int stat0, stat1, stat2;

	compute_flag = 1;
	stat0 = pthread_create(&schedule_thread, NULL, &schedule_trigger_thread, (void*) "Schedule thread" );
	stat1 = pthread_create(&app_thread, NULL, &send_app_sock_thread, (void*) "App thread" );
	stat2 = pthread_create(&stop_thread, NULL, &stop_nimblock_thread, (void*) "Stop thread");
	//pthread that sends scheduling triggers

	//join pthread that sends scheduling triggers
	pthread_join(schedule_thread, NULL);
	pthread_join(app_thread, NULL);
	pthread_join(stop_thread, NULL);
	compute_flag = 0;
	pthread_mutex_unlock(&sync_lock);
	printf("\r\n Quitting application .. \r\n");
	printf(" Test end \r\n");

	return 0;
}

void *compute_thread_entry_app(void *ptr)
{
	int bytes_rcvd;
	char buf[256];

	//Msg_remote * msg_buf = new Msg_remote();

	//pthread_mutex_lock(&sync_lock);
	//sleep(1);
	while (compute_flag == 1) {

		//printf("\r\nEntered read loop");
		pthread_mutex_lock(&msg_lock);
		while (done_writing != 1) {
			pthread_cond_wait(&read_cond, &msg_lock);
		}
		done_writing = 0;
		//bytes_rcvd = read(fd, &msg_buf, sizeof(msg_buf));
		do {
			bytes_rcvd = read(fd, &buf, sizeof(buf));
		} while ((bytes_rcvd < 0));

		pthread_mutex_unlock(&msg_lock);
		done_reading = 1;
		pthread_cond_signal(&read_cond);

		//printf("Reading %d bytes: ", bytes_rcvd);
		//printf(buf);
		std::istringstream iss(buf);
		std::vector<std::string> words(std::istream_iterator<std::string>{iss}, std::istream_iterator<std::string>());
		if (words[0]=="Retired") {
			int req_id = std::stoi(words[1]);
			int sock_fd = requests[req_id];
			printf("Sending resp for req %d to socket %d\n",req_id, sock_fd);
			std::string response = "Complete";
			int send_result = send(sock_fd, response.c_str(), response.length(), 0);
			if (send_result < 0) {
				perror("send failed");
				exit(EXIT_FAILURE);
			}
			//TODO closing early or something? idk
			//close(sock_fd);
			//requests.erase(req_id);
		}
		//memcpy(msg_buf, buf, sizeof(Msg_remote));

		//printf("\r\Done reading");
		//printf("\r\n Nimblock acked with msg %d, req id %d ", msg_buf->message_type, msg_buf->req_id);


		/*if (msg_buf->message_type == APP_RETIRED) {
			int sock_fd = requests[msg_buf->req_id];
			std::string response = "Complete";
			int send_result = send(sock_fd, response.c_str(), response.length(), 0);
			if (send_result < 0) {
				perror("send failed");
				exit(EXIT_FAILURE);
			}
			close(sock_fd);
			requests.erase(msg_buf->req_id);
		}*/
		//printf(buf);
		//pthread_mutex_unlock(&sync_lock);

	}

	return 0;
}

int rpmsg_create_ept(int rpfd, struct rpmsg_endpoint_info *eptinfo)
{
	int ret;

	ret = ioctl(rpfd, RPMSG_CREATE_EPT_IOCTL, eptinfo);
	if (ret)
		perror("Failed to create endpoint.\n");
	return ret;
}

static char *get_rpmsg_ept_dev_name(const char *rpmsg_char_name,
				    const char *ept_name,
				    char *ept_dev_name)
{
	char sys_rpmsg_ept_name_path[64];
	char svc_name[64];
	char *sys_rpmsg_path = "/sys/class/rpmsg";
	FILE *fp;
	int i;
	int ept_name_len;

	for (i = 0; i < 128; i++) {
		sprintf(sys_rpmsg_ept_name_path, "%s/%s/rpmsg%d/name",
			sys_rpmsg_path, rpmsg_char_name, i);
		printf("checking %s\n", sys_rpmsg_ept_name_path);
		if (access(sys_rpmsg_ept_name_path, F_OK) < 0)
			continue;
		fp = fopen(sys_rpmsg_ept_name_path, "r");
		if (!fp) {
			printf("failed to open %s\n", sys_rpmsg_ept_name_path);
			break;
		}
		fgets(svc_name, sizeof(svc_name), fp);
		fclose(fp);
		printf("svc_name: %s.\n",svc_name);
		ept_name_len = strlen(ept_name);
		if (ept_name_len > sizeof(svc_name))
			ept_name_len = sizeof(svc_name);
		if (!strncmp(svc_name, ept_name, ept_name_len)) {
			sprintf(ept_dev_name, "rpmsg%d", i);
			return ept_dev_name;
		}
	}

	printf("Not able to RPMsg endpoint file for %s:%s.\n",
	       rpmsg_char_name, ept_name);
	return NULL;
}

static int bind_rpmsg_chrdev(const char *rpmsg_dev_name)
{
	char fpath[256];
	char *rpmsg_chdrv = "rpmsg_chrdev";
	int fd;
	int ret;

	/* rpmsg dev overrides path */
	sprintf(fpath, "%s/devices/%s/driver_override",
		RPMSG_BUS_SYS, rpmsg_dev_name);
	fd = open(fpath, O_WRONLY);
	if (fd < 0) {
		fprintf(stderr, "Failed to open %s, %s\n",
			fpath, strerror(errno));
		return -EINVAL;
	}
	ret = write(fd, rpmsg_chdrv, strlen(rpmsg_chdrv) + 1);
	if (ret < 0) {
		fprintf(stderr, "Failed to write %s to %s, %s\n",
			rpmsg_chdrv, fpath, strerror(errno));
		return -EINVAL;
	}
	close(fd);

	/* bind the rpmsg device to rpmsg char driver */
	sprintf(fpath, "%s/drivers/%s/bind", RPMSG_BUS_SYS, rpmsg_chdrv);
	fd = open(fpath, O_WRONLY);
	if (fd < 0) {
		fprintf(stderr, "Failed to open %s, %s\n",
			fpath, strerror(errno));
		return -EINVAL;
	}
	ret = write(fd, rpmsg_dev_name, strlen(rpmsg_dev_name) + 1);
	if (ret < 0) {
		fprintf(stderr, "Failed to write %s to %s, %s\n",
			rpmsg_dev_name, fpath, strerror(errno));
		return -EINVAL;
	}
	close(fd);
	return 0;
}

static int get_rpmsg_chrdev_fd(const char *rpmsg_dev_name,
			       char *rpmsg_ctrl_name)
{
	char dpath[256];
	char fpath[256];
	char *rpmsg_ctrl_prefix = "rpmsg_ctrl";
	DIR *dir;
	struct dirent *ent;
	int fd;

	sprintf(dpath, "%s/devices/%s/rpmsg", RPMSG_BUS_SYS, rpmsg_dev_name);
	dir = opendir(dpath);
	if (dir == NULL) {
		fprintf(stderr, "Failed to open dir %s\n", dpath);
		return -EINVAL;
	}
	while ((ent = readdir(dir)) != NULL) {
		if (!strncmp(ent->d_name, rpmsg_ctrl_prefix,
			    strlen(rpmsg_ctrl_prefix))) {
			printf("Opening file %s.\n", ent->d_name);
			sprintf(fpath, "/dev/%s", ent->d_name);
			fd = open(fpath, O_RDWR | O_NONBLOCK);
			if (fd < 0) {
				fprintf(stderr,
					"Failed to open rpmsg char dev %s,%s\n",
					fpath, strerror(errno));
				return fd;
			}
			sprintf(rpmsg_ctrl_name, "%s", ent->d_name);
			return fd;
		}
	}

	fprintf(stderr, "No rpmsg char dev file is found\n");
	return -EINVAL;
}

int main(int argc, char *argv[])
{
	unsigned int size;
	int opt, ret;
	char *rpmsg_dev="virtio0.rpmsg-openamp-demo-channel.-1.0";
	char rpmsg_char_name[16];
	char fpath[256];
	struct rpmsg_endpoint_info eptinfo;
	char ept_dev_name[16];
	char ept_dev_path[32];
	curr_req_id = 0;

	while ((opt = getopt(argc, argv, "d:n:")) != -1) {
		switch (opt) {
		case 'd':
			rpmsg_dev = optarg;
			break;
		case 'n':
			ntimes = atoi(optarg);
			break;
		default:
			printf("getopt return unsupported option: -%c\n",opt);
			break;
		}
	}
	//printf("\r\n Matrix multiplication demo start \r\n");

	/* Load rpmsg_char driver */
	printf("\r\nMaster>probe rpmsg_char\r\n");
	ret = system("modprobe rpmsg_char");
	if (ret < 0) {
		perror("Failed to load rpmsg_char driver.\n");
		return -EINVAL;
	}

	printf("\r\n Open rpmsg dev %s! \r\n", rpmsg_dev);
	sprintf(fpath, "%s/devices/%s", RPMSG_BUS_SYS, rpmsg_dev);
	if (access(fpath, F_OK)) {
		fprintf(stderr, "Not able to access rpmsg device %s, %s\n",
			fpath, strerror(errno));
		return -EINVAL;
	}
	ret = bind_rpmsg_chrdev(rpmsg_dev);
	if (ret < 0)
		return ret;
	charfd = get_rpmsg_chrdev_fd(rpmsg_dev, rpmsg_char_name);
	if (charfd < 0)
		return charfd;

	/* Create endpoint from rpmsg char driver */
	strcpy(eptinfo.name, "rpmsg-openamp-demo-channel");
	eptinfo.src = 0;
	eptinfo.dst = 0xFFFFFFFF;
	ret = rpmsg_create_ept(charfd, &eptinfo);
	if (ret) {
		printf("failed to create RPMsg endpoint.\n");
		return -EINVAL;
	}
	if (!get_rpmsg_ept_dev_name(rpmsg_char_name, eptinfo.name,
				    ept_dev_name))
		return -EINVAL;
	sprintf(ept_dev_path, "/dev/%s", ept_dev_name);
	fd = open(ept_dev_path, O_RDWR | O_NONBLOCK);
	if (fd < 0) {
		perror("Failed to open rpmsg device.");
		close(charfd);
		return -1;
	}


	//pthread_mutex_lock(&sync_lock);

	printf("\r\n Creating ui_thread and compute_thread ... \r\n");

	//changed
	pthread_create(&ui_thread, NULL, &ui_thread_entry_app, (void*) "ui_thread");

	//changed
	pthread_create(&compute_thread, NULL, &compute_thread_entry_app, (void*) "compute_thread");
	pthread_join(ui_thread, NULL);

	pthread_join(compute_thread, NULL);

	close(fd);
	if (charfd >= 0)
		close(charfd);

	printf("\r\n Quitting application .. \r\n");

	pthread_mutex_destroy(&sync_lock);

	return 0;
}

