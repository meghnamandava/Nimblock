/*
 * nimblock_types_host.h
 *
 *  Created on: Apr 3, 2023
 *      Author: meghnamandava
 */

#ifndef NIMBLOCK_TYPES_HOST_H_
#define NIMBLOCK_TYPES_HOST_H_

//#define SCHED_INTERVAL 400000 /* Defined in us */
enum host_msg_type {
    SCHEDULE,
    ADD_APP,
    SHUTDOWN,
};

/* Application struct with only user-relevant information */
class Nimblock_msg {
    public:
        // load task in remote //std::vector<Task*> tasks;
        // load task in remote //std::vector<int*> dependency_list;
        // load task in remote //std::vector<int> num_deps;
		// load task in remote // XTime arrival_time;
		// load task in remote // XTime start_time, end_time;
		// load task in remote // XTime pr_start_time, pr_end_time;
        // double priority;
        // char* app_name;
		enum host_msg_type message_type; //0 to trigger scheduling, 1 to add app, 2 to shutdown
        int priority_level; // Real time priority, not queue priority
        int batch;
        int id;
        int req_id;
        // int occupancy;
        // load in remote // u64 latency;
        // int threshold;
        // int tasks_completed;
        // int parallelism; // defines the parallism factor for this application's DFG
    Nimblock_msg() : message_type(SCHEDULE) {}
    Nimblock_msg(host_msg_type msg_type, int p, int batch, int id, int req_id) : message_type(msg_type), priority_level(p), batch(batch), id(id), req_id(req_id) {}
};

enum remote_msg_type {
    APP_QUEUED,
    APP_RETIRED,
    ACK_SHUTDOWN,
	ACK_SCHED,
};

class Msg_remote {
public:
	enum remote_msg_type message_type; //0 to ack app queued, 1 to ack app retired, 2 to shutdown
	int req_id;

};

class request_data {
public:
	int socket;
	std::chrono::time_point<std::chrono::high_resolution_clock> start_time;
	std::chrono::time_point<std::chrono::high_resolution_clock> end_time;
	request_data(int socket,std::chrono::time_point<std::chrono::high_resolution_clock> start_time) : socket(socket), start_time(start_time) {}
};


#endif /* NIMBLOCK_TYPES_HOST_H_ */
