/*
 * nimblock_types_host.h
 *
 *  Created on: Apr 3, 2023
 *      Author: meghnamandava
 */

#ifndef NIMBLOCK_TYPES_HOST_H_
#define NIMBLOCK_TYPES_HOST_H_

//#define SCHED_INTERVAL 400000 /* Defined in us */

/* Application struct with only user-relevant information */
class Nimblock_msg {
    public:
        // load task in remote //std::vector<Task*> tasks;
        // load task in remote //std::vector<int*> dependency_list;
        // load task in remote //std::vector<int> num_deps;
		// load task in remote // XTime arrival_time;
		// load task in remote // XTime start_time, end_time;
		// load task in remote // XTime pr_start_time, pr_end_time;
        // double priority;
        // char* app_name;
	    int message_type; //0 to trigger scheduling, 1 to add app, 2 to shutdown
        int priority_level; // Real time priority, not queue priority
        int batch;
        int id;
        // int occupancy;
        // load in remote // u64 latency;
        // int threshold;
        // int tasks_completed;
        // int parallelism; // defines the parallism factor for this application's DFG
    Nimblock_msg() : message_type(0) {}
    Nimblock_msg(int msg_type, int p, int batch, int id) : message_type(msg_type), priority_level(p), batch(batch), id(id) {}
};


#endif /* NIMBLOCK_TYPES_HOST_H_ */
