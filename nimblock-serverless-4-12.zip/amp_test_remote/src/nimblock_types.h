/*
 * nimblock_types.h
 *
 *  Created on: Mar 30, 2023
 *      Author: meghnamandava
 */

#ifndef SRC_NIMBLOCK_TYPES_H_
#define SRC_NIMBLOCK_TYPES_H_

#include "xtime_l.h"

struct Task {
        int id; /* This task's index in its application's list */
        struct Application* app_id; /* Used to access app information */
        double priority;
        int batch;
        char **bin_name;
        int batch_completed;
        // int num_inputs;
        // int* input_sizes;
        // int num_outputs;
        // int* output_sizes;
        int num_args;
        int* arg_sizes;
        UINTPTR* arg_buffers;
        //int num_arg_buffers;
        int* const_values;
//        std::queue<std::vector<UINTPTR>> old_arg_buffers; // Preserved for future batches if necessary
        u64 latency;
        enum arg_proto* arg_protocols;
        struct arg_location* arg_locations;
        struct Slot* machine;
        bool queued;
        XTime tStart_ip, tEnd_ip;
        XTime tStart_pr, tEnd_pr;
        XTime tStart_run, tEnd_run;

};

struct Application {
        struct Task** tasks;
        //int num_tasks;
        int** dependency_list;
        int* num_deps;
        XTime arrival_time;
        XTime start_time, end_time;
        XTime pr_start_time, pr_end_time;
        double priority;
        char* app_name;
        int priority_level; // Real time priority, not queue priority
        int batch;
        int id;
        int occupancy;
        u64 latency;
        int threshold;
        int tasks_completed;
        int parallelism; // defines the parallism factor for this application's DFG
};

#endif /* SRC_NIMBLOCK_TYPES_H_ */
